    
    var songs = [{
            'name': 'Tamma Tamma Again',
            'artist': 'Badshah, Bappi Lahiri, Anuradha Paudwal',
            'album': 'Badrinath ki Dulhania',
            'duration': '2:56',
           'fileName': 'song1.mp3',
            'image': 'song1.jpg'

        },
        {
            'name': 'Humma Song',
            'artist': 'Badshah, Jubin Nautiyal, Shashaa Tirupati',
            'album': 'Ok Jaanu',
            'duration': '3:15',
            'fileName': 'song2.mp3',
            'image': 'song2.jpg'
        },
        {
            'name': 'Nashe Si Chad Gayi',
            'artist': 'Arijit Singh',
            'album': 'Befikre',
            'duration': '2:34',
            'fileName': 'song3.mp3',
            'image': 'song3.jpg'

        },
        {
            'name': 'The Breakup Song',
            'artist': 'Nakash Aziz, Arijit Singh, Badshah, Jonita Gandhi',
            'album': 'Ae Dil Hai Mushkil',
            'duration': '2:29',
            'fileName': 'song4.mp3',
            'image': 'song4.jpg'

        }]

        $('.welcome-screen button').on('click', function() {
        var name = $('#name-input').val();
        if(name.length > 2) {
        var message = "Welcome, " +  name;
        $('.main .user-name').text(message);
        $('.welcome-screen').addClass('hidden');
        $('.main').removeClass('hidden');
        }
        else {
            $('#name-input').addClass('error');
        }
    });

    function toggleSong() {
        var song = document.querySelector('audio');
        if(song.paused == true) {
            //console.log('Playing');
            $('.play-icon').removeClass('fa-play').addClass('fa-pause');
            song.play();
        }
        else {
            //console.log('Pausing');
            $('.play-icon').removeClass('fa-pause').addClass('fa-play');
            song.pause();
        }
    }

        function prettifyTime(num) {
        if(num < 10) {
            num = '0' + num;
        }
        return num;
    }

    function updateCurrentTime() {
        var song = document.querySelector('audio');
        var currentTimeInMinutes = Math.floor(song.currentTime/60);
        currentTimeInMinutes = prettifyTime(currentTimeInMinutes)
        var durationInMinutes = Math.floor(song.duration/60);
        durationInMinutes = prettifyTime(durationInMinutes);
        var currentTimeInSeconds = Math.floor(song.currentTime%60);
        currentTimeInSeconds = prettifyTime(currentTimeInSeconds);
        var durationInSeconds = Math.floor(song.duration%60);
        durationInSeconds = prettifyTime(durationInSeconds);
        $('.time-elapsed').text(currentTimeInMinutes + ':' + currentTimeInSeconds);
        $('.song-duration').text(durationInMinutes + ':' + durationInSeconds);
    }


    function changeCurrentSongDetails(songObj) {
        $('.current-song-image').attr('src','img/' + songObj.image)
        $('.current-song-name').text(songObj.name)
        $('.current-song-album').text(songObj.album)
    }

    function triggerSongEvent(songName){
        var audio = document.querySelector('audio');
        var currentSong = audio.src;
        if(currentSong.search(songName) != -1)
        {
            toggleSong();
        }
        else {
            audio.src = songName;
            toggleSong();
            //geCurrentSongDetails(songObj);
       }    
    }

    function addSongNameClickEvent(songObj,position) {
        var songName = songObj.fileName;
        position = position + 1;
        var id = '#song' + position;
        $(id).click(function() {
            triggerSongEvent(songName);    
        });
    }    

    function voiceActivate(){
        if (!('webkitSpeechRecognition' in window)) {
            upgrade();
        } else {
            var recognition = new webkitSpeechRecognition();
            recognition.continuous = false;
            recognition.interimResults = true
        }

        recognition.start();

        recognition.onresult = function(event) {
            var interim_text = '';
            var final_text = '';

            for (var i = event.resultIndex; i < event.results.length; ++i) {
              if (event.results[i].isFinal) {
                final_text += event.results[i][0].transcript;
              } else {
               interim_text += event.results[i][0].transcript;
              }
            }

            console.log('Final Text = ' + final_text);
            //console.log(interim_text);

            if(final_text.length > 0){
                $.ajax({
                  url: 'https://api.wit.ai/message',
                  data: {
                    'q': final_text,
                    'access_token' : '5CYTI7KTDTCGQH4PO3RKRPWRSPUZUO2T'
                  },
                  dataType: 'jsonp',
                  method: 'GET',
                  success: function(response) {
                    console.log("success!", response);

                    var option = response.entities.intent[0].value;

                    switch(option){
                        
                        case 'play' : 
                            var receivedName = '';
                            
                            if(response.entities.songName)
                                receivedName += response.entities.songName[0].value;

                            if(receivedName == 'current' || receivedName.length < 1){
                                toggleSong();
                                break;
                            }

                            console.log(receivedName);  
                            var regex = new RegExp(receivedName, "gi");
                            var songName = "";

                            for(var i=0; i<songs.length; i++){
                                var matched = "";
                                matched += songs[i].name.match(regex);
                                console.log("Count " + i + " : " + songs[i].name + " : " + matched);
                                if(matched != null);
                                {   
                                    if(matched.length > 4){
                                        songName += songs[i].fileName;
                                        break;
                                    }
                                }
                            }

                            console.log(songName);

                            if(songName.length > 1){
                                triggerSongEvent(songName);
                            }

                            break;

                        case 'pause' :

                            toggleSong();
                            break;

                    }

                  }
                });
            }
            
        };
    }

    $('#mic').on('click', function(){
        voiceActivate();
        
    });

    $('.play-icon').on('click', function() {
        toggleSong();
    });

    $('body').on('keypress',function(event) {
        // if (event.keyCode == 32)
        // {
        //     toggleSong();
        // }

        switch(event.keyCode){
            case 32:
                toggleSong();
                break;
            case 118:
                voiceActivate();
                break;    
        }
    });


    // for (var i = 0; i < fileNames.length ; i++) {
    //     addSongNameClickEvent(fileNames[i],i)
    // }

    window.onload = function() {

        changeCurrentSongDetails(songs[0]);
        for(var i =0; i < songs.length;i++) {
            var obj = songs[i];
            var name = '#song' + (i+1);
            var song = $(name);
            song.find('.song-name').text(obj.name);
            song.find('.song-artist').text(obj.artist);
            song.find('.song-album').text(obj.album);
            song.find('.song-length').text(obj.duration);
            addSongNameClickEvent(obj,i)
        }
        

        updateCurrentTime(); 
        setInterval(function() {
            updateCurrentTime();
        },1000);
        $('#songs').DataTable({
            paging: false
        });
    }